from Crypto.Cipher import AES

algo = AES.new('OurEncryptionKey', AES.MODE_CBC, '\xa3zi\xf14\x17\xf5\xab<\xc4\xa1Tk\x97\xfdv')

with open('1angecryption', "rb") as f:
	d = f.read()

d = algo.encrypt(d)

with open('2angecrypted_pycrypto', "wb") as f:
	f.write(d)