import struct
import sys
import binascii

source_file, target_file, result_file, encryption_key = sys.argv[1:6]

from Crypto.Cipher import AES
algo = AES
BS = 16

pad = lambda s: s + (BS - len(s) % BS) * "\0" # non-standard padding might be preferred for PDF

key = encryption_key

with open(source_file, "rb") as f:
    s = pad(f.read())

with open(target_file, "rb") as f:
    t = pad(f.read())

p = s[:BS] # our first plaintext block
ecb_dec = algo.new(key, algo.MODE_ECB)

size = len(s) - BS # we take the whole first 16 bits
c = "TEXT" + "/*"
c = pad(c)

c = ecb_dec.decrypt(c)
IV = "".join([chr(ord(c[i]) ^ ord(p[i])) for i in range(BS)])
cbc_enc = algo.new(key, algo.MODE_CBC, IV)
result = cbc_enc.encrypt(s)

result = result + "*/" + t[4:]

cbc_dec = algo.new(key, algo.MODE_CBC, IV)
with open("1angecryption", "wb") as f:
    f.write(cbc_dec.decrypt(pad(result)))

with open("angecrypt.py", "wb") as f:
    f.write("""from Crypto.Cipher import AES

algo = AES.new(%(key)s, AES.MODE_CBC, %(IV)s)

with open(%(source)s, "rb") as f:
	d = f.read()

d = algo.encrypt(d)

with open(%(target)s, "wb") as f:
	f.write(d)""" % {
        'key':`key`,
        'IV':`IV`,
        'source':"'1angecryption'",
        'target':"'2angecrypted_pycrypto'"})

with open("angecrypt.bat", "wb") as f:
    f.write("""xxd %(source)s
echo
openssl enc -aes-128-cbc -nopad -in %(source)s -out %(target)s -K %(key)s -iv %(IV)s
echo
xxd %(target)s""" % {
'key':"".join("%02X" % ord(i) for i in key),
'IV': "".join("%02X" % ord(i) for i in IV),
'source':"1angecryption",
'target':"2angecrypted_ssl"})
