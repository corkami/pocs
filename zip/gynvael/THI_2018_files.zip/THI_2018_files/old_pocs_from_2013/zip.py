import sys
import zipfile
zipfile.ZipFile(sys.argv[1], "r").printdir()

