by gynvael.coldwind//vx (http://gynvael.coldwind.pl/)

*** Slides:
http://goo.gl/iU1aT

*** Links:
http://goo.gl/rJ8ND - table with tests
http://www.icewall.pl/?p=467 - very long file names in Windows
http://en.wikipedia.org/wiki/Gifar - GIFAR
https://code.google.com/p/corkami/wiki/mix - CorkaMIX
http://gynvael.coldwind.pl/n/python_zipdl - extract single file from ZIP via HTTP (python)
http://research.swtch.com/zip - making of infinite recursion ZIP (r.zip)
http://gynvael.coldwind.pl/?id=30 - Unreal Commander bugs from 2007
http://www.pkware.com/documents/casestudies/APPNOTE.TXT - official ZIP file format reference
http://blog.cmpxchg8b.com/2012/09/fun-with-constrained-programming.html - RAR VM analysis
https://www.cr0.org/misc/jt-securitech-06-11.pdf - CRC32 preimage alg.
http://piggybird.net/?p=374 - PiggyBird CTF Team writeup on rar vm crackme
