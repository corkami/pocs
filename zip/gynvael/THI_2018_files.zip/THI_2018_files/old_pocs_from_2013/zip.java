// http://www.kodejava.org/examples/51.html
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

public class zip {
    public static void main(String[] args) {
        try {
            //
            // Create an instance of ZipFile to read a zip file
            // called sample.zip
            //
            ZipInputStream zip = new ZipInputStream(new FileInputStream("abstract.zip"));

            //
            // Here we start to iterate each entries inside
            // sample.zip
            //
            ZipEntry entry;
            while((entry = zip.getNextEntry()) != null)
            {

                //
                // Get some information about the entry such as
                // file name, its size.
                //
                System.out.println("File name: " + entry.getName()
                        + "; size: " + entry.getSize()
                        + "; compressed size: "
                        + entry.getCompressedSize());
                System.out.println();

                
            }
        } catch (ZipException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

