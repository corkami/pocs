#!/bin/bash

if [[ $# -eq 0 ]] ; then
  echo 'usage: gen_link_zip.sh <link_target>'
  exit 1
fi

HERE=`pwd`
TMPDIR="/tmp/frrrrzip"

mkdir $TMPDIR
cd $TMPDIR

ln -s "$1" link
zip -y ${HERE}/link.zip link
zipinfo ${HERE}/link.zip
rm -rf $TMPDIR



